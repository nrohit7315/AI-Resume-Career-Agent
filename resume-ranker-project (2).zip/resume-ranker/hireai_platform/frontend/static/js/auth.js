function setLoading(button, isLoading) {
  button.disabled = isLoading;
  button.classList.toggle("loading", isLoading);
}

function showError(bannerEl, message) {
  bannerEl.textContent = message;
  bannerEl.classList.add("visible");
}

function showSuccess(bannerEl, message) {
  bannerEl.textContent = message;
  bannerEl.classList.add("visible");
}

/** Extracts a readable message from a FastAPI/Pydantic error payload,
 * which can be a plain string OR a list of {msg, loc} validation errors. */
function extractErrorMessage(data) {
  if (!data || !data.detail) return "Something went wrong. Please try again.";
  if (typeof data.detail === "string") return data.detail;
  if (Array.isArray(data.detail)) {
    return data.detail.map((e) => e.msg).join(" ");
  }
  return "Something went wrong. Please try again.";
}
