async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  let data = null;
  try { data = await res.json(); } catch (_) { /* no body */ }
  if (!res.ok) {
    throw new Error(extractErrorMessage(data));
  }
  return data;
}

function statusBadge(status) {
  return `<span class="status-badge status-${status}">${status}</span>`;
}

function skillChips(skills, cls = "") {
  if (!skills || skills.length === 0) return "";
  return skills.map((s) => `<span class="skill-chip ${cls}">${s}</span>`).join("");
}

function formatDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  } catch (_) {
    return iso;
  }
}

function employmentTypeLabel(type) {
  const map = { full_time: "Full-time", part_time: "Part-time", internship: "Internship", contract: "Contract" };
  return map[type] || type;
}
