# HireAI Platform — Phase 1: Authentication

Register/Login system with role-based accounts (Candidate / Recruiter /
Admin), built as its own module (`hireai_platform/`) alongside the
Screening Room resume-ranking tool. This is the foundation the Job Board,
AI Career Agent, and other "Advanced Scope" pages will build on top of.

---

## What's included

- **Register & Login pages** — cinematic black/gold/crimson/emerald theme
  matching the Screening Room UI, with a subtle curtain-open entrance
  animation, live role toggle (Candidate/Recruiter), and inline
  validation.
- **Three account roles**: `job_seeker`, `recruiter` (self-registered),
  and `admin` (seeded only — see below). Each role lands on its own
  dashboard after login.
- **Real security**, not security theater:
  - Passwords hashed with PBKDF2-HMAC-SHA256 (260,000 iterations) + a
    unique random salt per user — no plaintext or reversible storage.
  - Session tokens are signed, expiring JWTs stored in an **HttpOnly**
    cookie (invisible to JS — blocks XSS token theft) with
    **SameSite=Strict** (blocks CSRF) and an environment-gated **Secure**
    flag (HTTPS-only in production).
  - Brute-force lockout: 5 failed login attempts locks an email out for
    15 minutes.
  - All database queries are parameterized (SQL-injection safe by
    construction).
- **SQLite storage** (`hireai_platform/data/platform.db`, gitignored) —
  a single dependency-free file with real transactions, chosen over raw
  JSON specifically so credential writes are atomic and crash-safe.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
python -c "import secrets; print(secrets.token_hex(32))"   # paste result into .env as PLATFORM_SECRET_KEY
```

## Run

```bash
uvicorn hireai_platform.backend.app:app --reload --port 9000
```
Open `http://localhost:9000`.

## Create the admin/owner account

Admin accounts are **not** self-registerable (only `job_seeker` and
`recruiter` are offered on the public `/register` page) — the
owner/evaluator role that will get elevated permissions to verify job
postings (Phase 2) must be created directly on the server:

```bash
python -m hireai_platform.seed_admin
```

## Run tests

```bash
python -m hireai_platform.tests.test_auth
```
15/15 passing, including regression tests for two real bugs found and
fixed during development (see PROJECT_NOTES_PRIVATE.md for the full
story): a Pydantic validator that silently skipped the "recruiter must
have a company name" check when the field was omitted, and a `Secure`
cookie flag that blocked sessions from working over local `http://`.

## What's next

Phase 2 (Job Board — recruiter role/company forms + admin verification
queue) builds directly on this: `require_role("recruiter")` and
`require_role("admin")` dependencies are already wired up in
`hireai_platform/backend/auth/routes.py`, ready for the new routes.

---

# Phase 2: Job Board (COMPLETE)

Recruiters post roles, an admin/owner verifies them before they go live,
candidates browse and apply — with a one-click **Quick Apply** for
in-platform roles and an honest **Application Assistant** (not an
auto-submit bot) for external job links.

## What's included

- **Recruiter**: `/jobs/new` — post a role (title, company, branch,
  location, employment type, description, requirements, salary range,
  optional external URL). Required skills are auto-detected from the
  description via the same NLP taxonomy matcher used in the Screening
  Room tool — zero extra cost, zero API calls.
- **Admin/Owner**: `/admin/jobs` — verification queue. Every job starts
  `pending` and is invisible to candidates until an admin approves it
  (or rejects it with a reason the recruiter can see).
- **Candidate**: `/jobs` — public board of verified roles only, with
  keyword search. `/jobs/{id}` — full detail + **Quick Apply** (one
  click, for in-platform roles) or **Get Application Assistance** (for
  externally-hosted roles).
- **Quick Apply**: candidates save their resume text once
  (`/dashboard` → Candidate view); after that, applying to any
  in-platform job is one click, and a tailored cover note is
  auto-drafted from a real skills-match against the job description.
- **Application Assistant** (`/apply/external`): candidates paste an
  external job posting's text; the assistant computes a skills-match
  score and drafts a cover note for them to review and submit
  *themselves* on the company's site. **This deliberately does not
  auto-submit anything on third-party sites** — see the "On automatic
  job applications" note below.
- **Recruiters see applicants** for their own approved postings only
  (`/jobs/mine` → Applicants) — enforced server-side, not just hidden in
  the UI.

## On automatic job applications

A generic "apply to any external job automatically" bot was explicitly
scoped out during planning: most job platforms' Terms of Service
prohibit automated/scripted applications (real risk of account bans),
every site has a different form/CAPTCHA/login-wall with no reliable
generic solution, and a submission the candidate never reviewed can
misrepresent them. The Application Assistant gives the real value
(fit analysis + drafted cover note) without the fragile, ToS-risky part.

## New database tables

`jobs`, `applications`, `candidate_resumes` — all in the same
`hireai_platform/data/platform.db` SQLite file, same parameterized-query
/ atomic-transaction guarantees as the `users` table.

## Run tests

```bash
python -m hireai_platform.tests.test_auth   # 15/15
python -m hireai_platform.tests.test_jobs   # 22/22
```

## What's next

Phase 3 — AI Career Agent (extended candidate intake, resume-based
candidate summary, job-fit suggestions, interdisciplinary path
suggestions, and an SVG career roadmap) — kept rule-based/offline per
your earlier direction (no live Claude API calls).
