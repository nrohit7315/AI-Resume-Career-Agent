"""One-time CLI to create an admin/owner account.

Admin accounts are intentionally NOT self-registerable through the public
/register page (see models.py: RegisterRequest.role only allows
job_seeker/recruiter) -- the owner/evaluator account that gets superior
permissions to verify job postings must be created out-of-band by whoever
controls the server. Run this once after first deploying:

    python -m hireai_platform.seed_admin

Note: use a real-looking domain for the email (e.g. you@yourcompany.com).
".local" / ".test" / ".invalid" / ".example" top-level domains are
rejected by the email validator as IANA special-use/reserved names.
"""
from __future__ import annotations

import getpass
import sys

from hireai_platform.backend.auth import db
from hireai_platform.backend.auth.security import hash_password, validate_password_strength


def main() -> int:
    db.init_db()

    print("=== HireAI — Create Admin / Owner Account ===")
    full_name = input("Full name: ").strip()
    email = input("Email: ").strip().lower()

    if db.email_exists(email):
        print(f"An account with email '{email}' already exists. Aborting.")
        return 1

    password = getpass.getpass("Password: ")
    problems = validate_password_strength(password)
    if problems:
        print("Password does not meet security requirements:")
        for p in problems:
            print(f"  - {p}")
        return 1

    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        print("Passwords do not match. Aborting.")
        return 1

    pw_hash = hash_password(password)
    user_id = db.create_user(full_name=full_name, email=email, password_hash=pw_hash, role="admin")
    print(f"\nAdmin account created (id={user_id}). You can now log in at /login.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
