"""Auth system regression tests.

Run with:
    python -m hireai_platform.tests.test_auth
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def run_all() -> bool:
    # Use an isolated temp DB per test run so tests never collide with real data.
    tmp_db = Path(tempfile.mkdtemp()) / "test_platform.db"
    import hireai_platform.backend.auth.db as db_module
    db_module.DB_PATH = tmp_db

    from fastapi.testclient import TestClient
    from hireai_platform.backend.app import app

    passed, failed = 0, 0

    def check(label: str, condition: bool):
        nonlocal passed, failed
        if condition:
            print(f"PASS  {label}")
            passed += 1
        else:
            print(f"FAIL  {label}")
            failed += 1

    with TestClient(app) as client:
        r = client.post("/auth/register", json={
            "full_name": "Test Seeker", "email": "seeker@test.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass", "role": "job_seeker",
        })
        check("register job_seeker succeeds (201)", r.status_code == 201)

        # Regression: recruiter without company_name must be rejected (422),
        # not silently accepted with company_name=null.
        r = client.post("/auth/register", json={
            "full_name": "Test Recruiter", "email": "recruiter@test.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass", "role": "recruiter",
        })
        check("recruiter WITHOUT company_name rejected (422)", r.status_code == 422)

        r = client.post("/auth/register", json={
            "full_name": "Test Recruiter", "email": "recruiter@test.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass", "role": "recruiter",
            "company_name": "Test Co",
        })
        check("recruiter WITH company_name accepted (201)", r.status_code == 201)

        r = client.post("/auth/register", json={
            "full_name": "Dup", "email": "seeker@test.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass", "role": "job_seeker",
        })
        check("duplicate email rejected (409)", r.status_code == 409)

        r = client.post("/auth/register", json={
            "full_name": "Weak", "email": "weak@test.com",
            "password": "weak", "confirm_password": "weak", "role": "job_seeker",
        })
        check("weak password rejected (422)", r.status_code == 422)

        r = client.post("/auth/register", json={
            "full_name": "Mismatch", "email": "mismatch@test.com",
            "password": "Str0ng!Pass", "confirm_password": "Different1!", "role": "job_seeker",
        })
        check("mismatched passwords rejected (422)", r.status_code == 422)

        # Regression: session cookie must actually work over http:// (Secure
        # flag must be environment-gated, not hardcoded True).
        r = client.post("/auth/login", json={"email": "seeker@test.com", "password": "Str0ng!Pass"})
        check("login with correct credentials succeeds (200)", r.status_code == 200)

        r = client.get("/auth/me")
        check("session cookie authenticates subsequent request (200)", r.status_code == 200)
        check("authenticated user has correct role", r.json().get("role") == "job_seeker")

        r = client.get("/dashboard")
        check("dashboard renders candidate view for job_seeker", "Candidate" in r.text)

        r = client.post("/auth/login", json={"email": "seeker@test.com", "password": "WrongPass!1"})
        check("wrong password rejected (401)", r.status_code == 401)

        for _ in range(5):
            r = client.post("/auth/login", json={"email": "seeker@test.com", "password": "WrongPass!1"})
        check("brute-force lockout triggers (429) after repeated failures", r.status_code == 429)

        r = client.post("/auth/logout")
        check("logout succeeds (200)", r.status_code == 200)

        r = client.get("/auth/me")
        check("session invalid after logout (401)", r.status_code == 401)

        r = client.post("/auth/login", json={"email": "recruiter@test.com", "password": "Str0ng!Pass"})
        r = client.get("/dashboard")
        check("recruiter sees recruiter dashboard", "Recruiter Console" in r.text)

    print(f"\n{passed} passed, {failed} failed out of {passed + failed}")
    return failed == 0


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
