"""Job Board regression tests.

Run with:
    python -m hireai_platform.tests.test_jobs
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def run_all() -> bool:
    tmp_db = Path(tempfile.mkdtemp()) / "test_platform.db"
    import hireai_platform.backend.auth.db as auth_db_module
    auth_db_module.DB_PATH = tmp_db

    from fastapi.testclient import TestClient
    from hireai_platform.backend.app import app
    from hireai_platform.backend.auth import db as auth_db
    from hireai_platform.backend.auth.security import hash_password

    passed, failed = 0, 0

    def check(label: str, condition: bool):
        nonlocal passed, failed
        if condition:
            print(f"PASS  {label}")
            passed += 1
        else:
            print(f"FAIL  {label}")
            failed += 1

    with TestClient(app) as client:
        client.post("/auth/register", json={
            "full_name": "Rahul Recruiter", "email": "rahul@acme.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass",
            "role": "recruiter", "company_name": "Acme Corp",
        })
        client.post("/auth/register", json={
            "full_name": "Priya Candidate", "email": "priya@example.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass", "role": "job_seeker",
        })
        # Admin accounts are seeded directly, never via public /auth/register.
        auth_db.create_user("Admin Owner", "admin@hireai-platform.com", hash_password("AdminPass1!"), "admin")

        client.post("/auth/login", json={"email": "rahul@acme.com", "password": "Str0ng!Pass"})
        r = client.post("/api/jobs", json={
            "title": "AI/ML Engineer", "company_name": "Acme Corp", "employment_type": "full_time",
            "description": "We need a Python engineer with machine learning, NLP, and scikit-learn experience.",
            "required_skills": [], "min_experience_years": 2,
        })
        check("recruiter can create a job (201)", r.status_code == 201)
        job_id = r.json()["id"]
        check("new job defaults to pending status", r.json()["status"] == "pending")
        check("required skills auto-detected from description", "python" in r.json()["required_skills"])

        client.post("/auth/login", json={"email": "priya@example.com", "password": "Str0ng!Pass"})
        r = client.get("/api/jobs")
        check("pending job is NOT visible on public board", len(r.json()) == 0)

        r = client.post("/api/jobs", json={
            "title": "x", "company_name": "y", "employment_type": "full_time",
            "description": "z" * 40, "required_skills": [],
        })
        check("job_seeker cannot create a job (403)", r.status_code == 403)

        client.post("/auth/login", json={"email": "admin@hireai-platform.com", "password": "AdminPass1!"})
        r = client.get("/api/admin/jobs/pending")
        check("admin sees the pending job in the queue", len(r.json()) == 1)

        r = client.post(f"/api/admin/jobs/{job_id}/approve")
        check("admin can approve a job (200)", r.status_code == 200)
        check("approved job status updates", r.json()["status"] == "approved")

        client.post("/auth/login", json={"email": "priya@example.com", "password": "Str0ng!Pass"})
        r = client.get("/api/jobs")
        check("approved job IS visible on public board", len(r.json()) == 1)

        # Quick Apply without a saved resume should still work (no auto cover note)
        r = client.post(f"/api/jobs/{job_id}/apply", json={})
        check("quick apply works without a saved resume", r.status_code == 201)
        check("no auto cover note without a saved resume", r.json()["cover_note"] is None)

        r = client.post(f"/api/jobs/{job_id}/apply", json={})
        check("duplicate quick apply rejected (409)", r.status_code == 409)

        r = client.get("/api/applications/mine")
        check("candidate sees their own application", len(r.json()) == 1)

        client.post("/auth/login", json={"email": "rahul@acme.com", "password": "Str0ng!Pass"})
        r = client.get(f"/api/jobs/{job_id}/applicants")
        check("recruiter can view applicants for own job", r.status_code == 200 and len(r.json()) == 1)

        # Second recruiter must NOT see the first recruiter's applicants
        client.post("/auth/register", json={
            "full_name": "Other Recruiter", "email": "other@othercorp.com",
            "password": "Str0ng!Pass", "confirm_password": "Str0ng!Pass",
            "role": "recruiter", "company_name": "OtherCorp",
        })
        client.post("/auth/login", json={"email": "other@othercorp.com", "password": "Str0ng!Pass"})
        r = client.get(f"/api/jobs/{job_id}/applicants")
        check("recruiter CANNOT view another recruiter's applicants (403)", r.status_code == 403)

        # External-assist requires a saved resume
        client.post("/auth/login", json={"email": "priya@example.com", "password": "Str0ng!Pass"})
        r = client.post("/api/jobs/external-assist", json={
            "job_title": "ML Engineer", "company_name": "External Co",
            "job_description_text": "Looking for an ML engineer with Python and NLP skills.",
        })
        check("external-assist requires a saved resume first (400)", r.status_code == 400)

        client.post("/api/resume/text", json={
            "resume_text": "Python developer with machine learning and NLP experience, 3 years.",
        })
        r = client.post("/api/jobs/external-assist", json={
            "job_title": "ML Engineer", "company_name": "External Co",
            "job_description_text": "Looking for an ML engineer with Python and NLP skills.",
        })
        check("external-assist succeeds once resume is saved (200)", r.status_code == 200)
        check("external-assist returns a cover note draft", len(r.json()["suggested_cover_note"]) > 0)
        check("external-assist never claims to auto-submit", "auto-submit" in r.json()["note"].lower())

        # Rejection flow
        client.post("/auth/login", json={"email": "rahul@acme.com", "password": "Str0ng!Pass"})
        r = client.post("/api/jobs", json={
            "title": "Bad Role", "company_name": "Acme Corp", "employment_type": "full_time",
            "description": "z" * 40, "required_skills": [],
        })
        bad_job_id = r.json()["id"]
        client.post("/auth/login", json={"email": "admin@hireai-platform.com", "password": "AdminPass1!"})
        r = client.post(f"/api/admin/jobs/{bad_job_id}/reject", json={"rejection_reason": "Incomplete description"})
        check("admin can reject a job with a reason (200)", r.status_code == 200)
        check("rejected job carries the reason", r.json()["rejection_reason"] == "Incomplete description")

        client.post("/auth/login", json={"email": "priya@example.com", "password": "Str0ng!Pass"})
        r = client.get("/api/jobs")
        check("rejected job never appears on public board", all(j["id"] != bad_job_id for j in r.json()))

    print(f"\n{passed} passed, {failed} failed out of {passed + failed}")
    return failed == 0


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
