"""Job-fit helpers for the Job Board.

Deliberately reuses the same offline NLP building blocks from the
resume-ranker package (`src/`) instead of adding a new dependency or an
API call -- keeps this phase's cost at zero and its behavior consistent
with the Screening Room tool.

Also implements the "autofill assistant" for external job links: per the
earlier scoping discussion, this does NOT auto-submit anything on a
third-party site (fragile, ToS-risky, and there's no generic way to do it
reliably). Instead it takes the pasted job description + the candidate's
stored resume and produces a tailored cover note + a skills-match summary
for the candidate to review and use when they apply themselves.
"""
from __future__ import annotations

import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.features.skills_extractor import extract_skills
from src.ranking.feature_scores import skills_match_score
from src.similarity.tfidf_matcher import tfidf_similarity


def suggest_skills_from_description(description: str) -> list[str]:
    """Used to pre-fill the recruiter's "required skills" field from their
    pasted job description text -- a small convenience, not required."""
    return extract_skills(description)["skills"]


def compute_job_fit(resume_text: str, job_description: str, job_required_skills: list[str]) -> dict:
    candidate_skills = extract_skills(resume_text)["skills"]
    skills_result = skills_match_score(candidate_skills, job_required_skills)
    similarity_score = tfidf_similarity(resume_text, job_description)

    return {
        "skills_match_score": skills_result["score"],
        "matched_skills": skills_result["matched"],
        "missing_skills": skills_result["missing"],
        "semantic_similarity": similarity_score,
    }


def generate_cover_note(full_name: str, job_title: str, company_name: str, fit: dict) -> str:
    """Rule-based cover note draft -- no LLM call, fully deterministic and
    free. Candidate is expected to review/edit before using it anywhere.
    """
    matched = fit["matched_skills"]
    matched_preview = ", ".join(matched[:5]) if matched else "a strong foundation in related tools"

    lines = [
        f"Dear Hiring Team at {company_name},",
        "",
        f"I'm writing to express my interest in the {job_title} position. "
        f"My background includes hands-on experience with {matched_preview}, "
        "which I believe aligns well with what this role requires.",
        "",
    ]

    if fit["missing_skills"]:
        lines.append(
            "I'm also actively growing my skills in "
            f"{', '.join(fit['missing_skills'][:3])}, and I'm confident I can "
            "ramp up quickly given my existing foundation."
        )
        lines.append("")

    lines.append(
        f"I'd welcome the opportunity to discuss how I can contribute to "
        f"{company_name}'s team. Thank you for your time and consideration."
    )
    lines.append("")
    lines.append(f"Best regards,\n{full_name}")

    return "\n".join(lines)
