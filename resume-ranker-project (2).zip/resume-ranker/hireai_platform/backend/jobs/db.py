"""SQLite layer for the Job Board: jobs, applications, and a lightweight
per-candidate stored-resume table (enables true one-click Quick Apply
without re-uploading every time).

Same conventions as auth/db.py: parameterized queries only, atomic SQLite
transactions, single dependency-free file on disk.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from hireai_platform.backend.auth.db import get_conn

VALID_JOB_STATUSES = {"pending", "approved", "rejected"}
VALID_APPLICATION_STATUSES = {"submitted", "reviewed", "shortlisted", "rejected"}
VALID_EMPLOYMENT_TYPES = {"full_time", "part_time", "internship", "contract"}


def init_jobs_tables() -> None:
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recruiter_id INTEGER NOT NULL REFERENCES users(id),
                title TEXT NOT NULL,
                company_name TEXT NOT NULL,
                branch TEXT,
                location TEXT,
                employment_type TEXT NOT NULL,
                description TEXT NOT NULL,
                requirements TEXT,
                required_skills_json TEXT NOT NULL DEFAULT '[]',
                min_experience_years REAL DEFAULT 0,
                salary_range TEXT,
                external_apply_url TEXT,
                status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
                rejection_reason TEXT,
                reviewed_by INTEGER REFERENCES users(id),
                reviewed_at TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL REFERENCES jobs(id),
                candidate_id INTEGER NOT NULL REFERENCES users(id),
                application_type TEXT NOT NULL DEFAULT 'quick_apply',
                cover_note TEXT,
                status TEXT NOT NULL DEFAULT 'submitted' CHECK(status IN ('submitted','reviewed','shortlisted','rejected')),
                applied_at TEXT NOT NULL,
                UNIQUE(job_id, candidate_id)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS candidate_resumes (
                user_id INTEGER PRIMARY KEY REFERENCES users(id),
                resume_text TEXT NOT NULL,
                file_name TEXT,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_recruiter ON jobs(recruiter_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_applications_job ON applications(job_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_applications_candidate ON applications(candidate_id)")


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------
def create_job(recruiter_id: int, data: dict) -> int:
    with get_conn() as conn:
        cursor = conn.execute(
            """
            INSERT INTO jobs (
                recruiter_id, title, company_name, branch, location, employment_type,
                description, requirements, required_skills_json, min_experience_years,
                salary_range, external_apply_url, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
            """,
            (
                recruiter_id, data["title"], data["company_name"], data.get("branch"),
                data.get("location"), data["employment_type"], data["description"],
                data.get("requirements"), json.dumps(data.get("required_skills", [])),
                data.get("min_experience_years", 0), data.get("salary_range"),
                data.get("external_apply_url"), datetime.now(timezone.utc).isoformat(),
            ),
        )
        return cursor.lastrowid


def get_job(job_id: int) -> sqlite3.Row | None:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        return cursor.fetchone()


def list_approved_jobs(keyword: str | None = None) -> list[sqlite3.Row]:
    with get_conn() as conn:
        if keyword:
            like = f"%{keyword.lower()}%"
            cursor = conn.execute(
                """
                SELECT * FROM jobs
                WHERE status = 'approved'
                AND (LOWER(title) LIKE ? OR LOWER(company_name) LIKE ? OR LOWER(description) LIKE ?)
                ORDER BY created_at DESC
                """,
                (like, like, like),
            )
        else:
            cursor = conn.execute("SELECT * FROM jobs WHERE status = 'approved' ORDER BY created_at DESC")
        return cursor.fetchall()


def list_jobs_by_recruiter(recruiter_id: int) -> list[sqlite3.Row]:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM jobs WHERE recruiter_id = ? ORDER BY created_at DESC", (recruiter_id,))
        return cursor.fetchall()


def list_pending_jobs() -> list[sqlite3.Row]:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM jobs WHERE status = 'pending' ORDER BY created_at ASC")
        return cursor.fetchall()


def review_job(job_id: int, admin_id: int, approve: bool, rejection_reason: str | None = None) -> None:
    with get_conn() as conn:
        conn.execute(
            """
            UPDATE jobs SET status = ?, rejection_reason = ?, reviewed_by = ?, reviewed_at = ?
            WHERE id = ?
            """,
            (
                "approved" if approve else "rejected",
                None if approve else rejection_reason,
                admin_id,
                datetime.now(timezone.utc).isoformat(),
                job_id,
            ),
        )


# ---------------------------------------------------------------------------
# Applications
# ---------------------------------------------------------------------------
def create_application(job_id: int, candidate_id: int, application_type: str, cover_note: str | None) -> int | None:
    """Returns the new application id, or None if the candidate already applied
    (UNIQUE(job_id, candidate_id) constraint) -- caller turns that into a 409.
    """
    try:
        with get_conn() as conn:
            cursor = conn.execute(
                """
                INSERT INTO applications (job_id, candidate_id, application_type, cover_note, applied_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (job_id, candidate_id, application_type, cover_note, datetime.now(timezone.utc).isoformat()),
            )
            return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None


def has_applied(job_id: int, candidate_id: int) -> bool:
    with get_conn() as conn:
        cursor = conn.execute(
            "SELECT 1 FROM applications WHERE job_id = ? AND candidate_id = ?", (job_id, candidate_id)
        )
        return cursor.fetchone() is not None


def list_applications_for_job(job_id: int) -> list[sqlite3.Row]:
    with get_conn() as conn:
        cursor = conn.execute(
            """
            SELECT applications.*, users.full_name, users.email
            FROM applications
            JOIN users ON users.id = applications.candidate_id
            WHERE job_id = ?
            ORDER BY applied_at DESC
            """,
            (job_id,),
        )
        return cursor.fetchall()


def list_applications_for_candidate(candidate_id: int) -> list[sqlite3.Row]:
    with get_conn() as conn:
        cursor = conn.execute(
            """
            SELECT applications.*, jobs.title, jobs.company_name, jobs.status as job_status
            FROM applications
            JOIN jobs ON jobs.id = applications.job_id
            WHERE candidate_id = ?
            ORDER BY applied_at DESC
            """,
            (candidate_id,),
        )
        return cursor.fetchall()


# ---------------------------------------------------------------------------
# Candidate stored resume (enables one-click Quick Apply)
# ---------------------------------------------------------------------------
def upsert_candidate_resume(user_id: int, resume_text: str, file_name: str | None) -> None:
    with get_conn() as conn:
        conn.execute(
            """
            INSERT INTO candidate_resumes (user_id, resume_text, file_name, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                resume_text = excluded.resume_text,
                file_name = excluded.file_name,
                updated_at = excluded.updated_at
            """,
            (user_id, resume_text, file_name, datetime.now(timezone.utc).isoformat()),
        )


def get_candidate_resume(user_id: int) -> sqlite3.Row | None:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM candidate_resumes WHERE user_id = ?", (user_id,))
        return cursor.fetchone()
