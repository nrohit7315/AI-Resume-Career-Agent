"""Job Board API routes."""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException, status

from hireai_platform.backend.auth.models import UserOut
from hireai_platform.backend.auth.routes import require_role
from hireai_platform.backend.jobs import db
from hireai_platform.backend.jobs.matcher import compute_job_fit, generate_cover_note, suggest_skills_from_description
from hireai_platform.backend.jobs.models import (
    ApplicationCreateRequest,
    ExternalAssistRequest,
    JobCreateRequest,
    JobOut,
    JobReviewRequest,
    ResumeUploadTextRequest,
)

router = APIRouter(prefix="/api", tags=["jobs"])


def _row_to_job_out(row) -> JobOut:
    return JobOut(
        id=row["id"], recruiter_id=row["recruiter_id"], title=row["title"],
        company_name=row["company_name"], branch=row["branch"], location=row["location"],
        employment_type=row["employment_type"], description=row["description"],
        requirements=row["requirements"], required_skills=json.loads(row["required_skills_json"]),
        min_experience_years=row["min_experience_years"], salary_range=row["salary_range"],
        external_apply_url=row["external_apply_url"], status=row["status"],
        rejection_reason=row["rejection_reason"], created_at=row["created_at"],
    )


# ---------------------------------------------------------------------------
# Recruiter: post + manage own roles
# ---------------------------------------------------------------------------
@router.post("/jobs", response_model=JobOut, status_code=status.HTTP_201_CREATED)
def create_job(payload: JobCreateRequest, user: UserOut = Depends(require_role("recruiter"))):
    required_skills = payload.required_skills or suggest_skills_from_description(payload.description)
    job_id = db.create_job(
        recruiter_id=user.id,
        data={**payload.model_dump(), "required_skills": required_skills},
    )
    return _row_to_job_out(db.get_job(job_id))


@router.get("/jobs/mine", response_model=list[JobOut])
def my_jobs(user: UserOut = Depends(require_role("recruiter"))):
    return [_row_to_job_out(r) for r in db.list_jobs_by_recruiter(user.id)]


@router.get("/jobs/{job_id}/applicants")
def job_applicants(job_id: int, user: UserOut = Depends(require_role("recruiter", "admin"))):
    job = db.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found.")
    if user.role == "recruiter" and job["recruiter_id"] != user.id:
        raise HTTPException(status_code=403, detail="You can only view applicants for your own postings.")

    rows = db.list_applications_for_job(job_id)
    return [
        {
            "id": r["id"], "candidate_name": r["full_name"], "candidate_email": r["email"],
            "application_type": r["application_type"], "cover_note": r["cover_note"],
            "status": r["status"], "applied_at": r["applied_at"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Admin: verification queue
# ---------------------------------------------------------------------------
@router.get("/admin/jobs/pending", response_model=list[JobOut])
def pending_jobs(user: UserOut = Depends(require_role("admin"))):
    return [_row_to_job_out(r) for r in db.list_pending_jobs()]


@router.post("/admin/jobs/{job_id}/approve", response_model=JobOut)
def approve_job(job_id: int, user: UserOut = Depends(require_role("admin"))):
    job = db.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found.")
    db.review_job(job_id, admin_id=user.id, approve=True)
    return _row_to_job_out(db.get_job(job_id))


@router.post("/admin/jobs/{job_id}/reject", response_model=JobOut)
def reject_job(job_id: int, payload: JobReviewRequest, user: UserOut = Depends(require_role("admin"))):
    job = db.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found.")
    db.review_job(job_id, admin_id=user.id, approve=False, rejection_reason=payload.rejection_reason)
    return _row_to_job_out(db.get_job(job_id))


# ---------------------------------------------------------------------------
# Public / candidate: browse + apply
# ---------------------------------------------------------------------------
@router.get("/jobs", response_model=list[JobOut])
def list_jobs(keyword: str | None = None):
    return [_row_to_job_out(r) for r in db.list_approved_jobs(keyword)]


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job_detail(job_id: int):
    row = db.get_job(job_id)
    if row is None or row["status"] != "approved":
        raise HTTPException(status_code=404, detail="Job not found.")
    return _row_to_job_out(row)


@router.post("/jobs/{job_id}/apply", status_code=status.HTTP_201_CREATED)
def quick_apply(
    job_id: int,
    payload: ApplicationCreateRequest,
    user: UserOut = Depends(require_role("job_seeker")),
):
    job = db.get_job(job_id)
    if job is None or job["status"] != "approved":
        raise HTTPException(status_code=404, detail="Job not found or not currently accepting applications.")

    if job["external_apply_url"]:
        raise HTTPException(
            status_code=400,
            detail="This role is hosted on an external site. Use the Application Assistant instead of Quick Apply.",
        )

    if db.has_applied(job_id, user.id):
        raise HTTPException(status_code=409, detail="You've already applied to this role.")

    resume_row = db.get_candidate_resume(user.id)
    cover_note = payload.cover_note
    if not cover_note and resume_row:
        fit = compute_job_fit(resume_row["resume_text"], job["description"], json.loads(job["required_skills_json"]))
        cover_note = generate_cover_note(user.full_name, job["title"], job["company_name"], fit)

    application_id = db.create_application(job_id, user.id, "quick_apply", cover_note)
    if application_id is None:
        raise HTTPException(status_code=409, detail="You've already applied to this role.")

    return {"id": application_id, "message": "Application submitted.", "cover_note": cover_note}


@router.get("/applications/mine")
def my_applications(user: UserOut = Depends(require_role("job_seeker"))):
    rows = db.list_applications_for_candidate(user.id)
    return [
        {
            "id": r["id"], "job_id": r["job_id"], "job_title": r["title"],
            "company_name": r["company_name"], "job_status": r["job_status"],
            "status": r["status"], "applied_at": r["applied_at"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Candidate resume storage (enables one-click Quick Apply)
# ---------------------------------------------------------------------------
@router.post("/resume/text")
def save_resume_text(payload: ResumeUploadTextRequest, user: UserOut = Depends(require_role("job_seeker"))):
    db.upsert_candidate_resume(user.id, payload.resume_text, file_name=None)
    return {"message": "Resume saved. Quick Apply is now available on any job listing."}


@router.get("/resume/status")
def resume_status(user: UserOut = Depends(require_role("job_seeker"))):
    row = db.get_candidate_resume(user.id)
    return {"has_resume": row is not None, "updated_at": row["updated_at"] if row else None}


# ---------------------------------------------------------------------------
# External Application Assistant (NOT auto-submit -- see matcher.py docstring)
# ---------------------------------------------------------------------------
@router.post("/jobs/external-assist")
def external_assist(payload: ExternalAssistRequest, user: UserOut = Depends(require_role("job_seeker"))):
    resume_row = db.get_candidate_resume(user.id)
    if resume_row is None:
        raise HTTPException(
            status_code=400,
            detail="Save your resume first (Candidate dashboard) so the assistant has something to match against.",
        )

    required_skills = suggest_skills_from_description(payload.job_description_text)
    fit = compute_job_fit(resume_row["resume_text"], payload.job_description_text, required_skills)
    cover_note = generate_cover_note(user.full_name, payload.job_title, payload.company_name, fit)

    return {
        "fit": fit,
        "suggested_cover_note": cover_note,
        "note": "Review and edit this before submitting -- this assistant does not auto-submit applications on external sites.",
    }
