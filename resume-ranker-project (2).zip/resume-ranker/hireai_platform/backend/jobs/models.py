"""Request/response schemas for the Job Board."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator

EmploymentType = Literal["full_time", "part_time", "internship", "contract"]


class JobCreateRequest(BaseModel):
    title: str = Field(min_length=3, max_length=150)
    company_name: str = Field(min_length=1, max_length=150)
    branch: str | None = Field(default=None, max_length=150)
    location: str | None = Field(default=None, max_length=150)
    employment_type: EmploymentType
    description: str = Field(min_length=30, max_length=8000)
    requirements: str | None = Field(default=None, max_length=4000)
    required_skills: list[str] = Field(default_factory=list)
    min_experience_years: float = Field(default=0, ge=0, le=50)
    salary_range: str | None = Field(default=None, max_length=100)
    external_apply_url: str | None = Field(default=None, max_length=500)

    @field_validator("title", "company_name")
    @classmethod
    def not_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("This field cannot be blank.")
        return v

    @field_validator("external_apply_url")
    @classmethod
    def looks_like_url(cls, v: str | None) -> str | None:
        if v and v.strip() and not (v.startswith("http://") or v.startswith("https://")):
            raise ValueError("External apply URL must start with http:// or https://")
        return v.strip() if v else v


class JobReviewRequest(BaseModel):
    rejection_reason: str | None = Field(default=None, max_length=500)


class JobOut(BaseModel):
    id: int
    recruiter_id: int
    title: str
    company_name: str
    branch: str | None
    location: str | None
    employment_type: str
    description: str
    requirements: str | None
    required_skills: list[str]
    min_experience_years: float
    salary_range: str | None
    external_apply_url: str | None
    status: str
    rejection_reason: str | None
    created_at: str


class ApplicationCreateRequest(BaseModel):
    cover_note: str | None = Field(default=None, max_length=2000)


class ApplicationOut(BaseModel):
    id: int
    job_id: int
    candidate_id: int
    application_type: str
    cover_note: str | None
    status: str
    applied_at: str


class ExternalAssistRequest(BaseModel):
    job_title: str = Field(min_length=2, max_length=150)
    company_name: str = Field(min_length=1, max_length=150)
    job_description_text: str = Field(
        min_length=30, max_length=8000,
        description="Paste the job description text from the external posting.",
    )
    external_url: str | None = Field(default=None, max_length=500)


class ResumeUploadTextRequest(BaseModel):
    resume_text: str = Field(min_length=50, max_length=20000)
