"""HireAI Platform — main application entry point.

Run with:
    uvicorn hireai_platform.backend.app:app --reload --port 9000

Then open http://localhost:9000 in a browser.
"""
from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

load_dotenv()  # loads PLATFORM_SECRET_KEY etc. from a local .env if present

from hireai_platform.backend.auth import db
from hireai_platform.backend.auth.routes import get_current_user, router as auth_router  # noqa: E402
from hireai_platform.backend.auth.models import UserOut  # noqa: E402
from hireai_platform.backend.jobs import db as jobs_db  # noqa: E402
from hireai_platform.backend.jobs.routes import router as jobs_router  # noqa: E402

BASE_DIR = Path(__file__).resolve().parents[1]

app = FastAPI(title="HireAI Platform", version="0.1.0")

app.include_router(auth_router)
app.include_router(jobs_router)
app.mount("/static", StaticFiles(directory=BASE_DIR / "frontend" / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "frontend" / "templates")


@app.on_event("startup")
def on_startup():
    db.init_db()
    jobs_db.init_jobs_tables()


def _get_optional_user(request: Request) -> UserOut | None:
    token = request.cookies.get("hireai_session")
    if not token:
        return None
    try:
        return get_current_user(hireai_session=token)
    except Exception:  # noqa: BLE001 - any invalid/expired token just means "not logged in"
        return None


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    user = _get_optional_user(request)
    if user:
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "login.html")


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    user = _get_optional_user(request)
    if user:
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "register.html")


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    user = _get_optional_user(request)
    if user:
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "login.html")


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    user = _get_optional_user(request)
    if not user:
        return RedirectResponse(url="/login")

    template_by_role = {
        "job_seeker": "dashboard_seeker.html",
        "recruiter": "dashboard_recruiter.html",
        "admin": "dashboard_admin.html",
    }
    template_name = template_by_role.get(user.role, "dashboard_seeker.html")
    return templates.TemplateResponse(request, template_name, {"user": user})


@app.get("/logout", response_class=HTMLResponse)
def logout_page(request: Request):
    response = RedirectResponse(url="/login")
    response.delete_cookie("hireai_session", path="/")
    return response


# ---------------------------------------------------------------------------
# Job Board pages
# ---------------------------------------------------------------------------
def _require_login(request: Request) -> UserOut | RedirectResponse:
    user = _get_optional_user(request)
    if not user:
        return RedirectResponse(url="/login")
    return user


@app.get("/jobs", response_class=HTMLResponse)
def job_board_page(request: Request):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    return templates.TemplateResponse(request, "job_board.html", {"user": result})


@app.get("/jobs/new", response_class=HTMLResponse)
def job_new_page(request: Request):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    if result.role != "recruiter":
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "job_new.html", {"user": result})


@app.get("/jobs/mine", response_class=HTMLResponse)
def job_mine_page(request: Request):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    if result.role != "recruiter":
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "job_mine.html", {"user": result})


@app.get("/jobs/{job_id}", response_class=HTMLResponse)
def job_detail_page(request: Request, job_id: int):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    return templates.TemplateResponse(request, "job_detail.html", {"user": result, "job_id": job_id})


@app.get("/apply/external", response_class=HTMLResponse)
def apply_external_page(request: Request):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    if result.role != "job_seeker":
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "apply_external.html", {"user": result})


@app.get("/admin/jobs", response_class=HTMLResponse)
def admin_jobs_page(request: Request):
    result = _require_login(request)
    if isinstance(result, RedirectResponse):
        return result
    if result.role != "admin":
        return RedirectResponse(url="/dashboard")
    return templates.TemplateResponse(request, "admin_jobs.html", {"user": result})
