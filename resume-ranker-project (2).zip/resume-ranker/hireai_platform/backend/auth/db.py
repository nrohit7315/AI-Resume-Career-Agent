"""SQLite-backed user store.

Why SQLite over a raw JSON file: account credentials need atomic,
crash-safe writes (a half-written JSON file on a power loss mid-registration
would corrupt every other user's data too, since it's one shared file).
SQLite gives real transactions and per-row updates while still being a
single, dependency-free file on disk (Python's `sqlite3` is stdlib) --
no separate database server to run or secure. Fully compatible with the
"low memory footprint, no external service" requirement.

All queries use parameterized placeholders (`?`) -- never string
interpolation -- so this layer is not SQL-injectable by construction.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[2] / "data" / "platform.db"

VALID_ROLES = {"job_seeker", "recruiter", "admin"}


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_conn():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('job_seeker', 'recruiter', 'admin')),
                company_name TEXT,
                is_verified INTEGER NOT NULL DEFAULT 0,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)")


def create_user(full_name: str, email: str, password_hash: str, role: str, company_name: str | None = None) -> int:
    if role not in VALID_ROLES:
        raise ValueError(f"Invalid role: {role}")

    with get_conn() as conn:
        cursor = conn.execute(
            """
            INSERT INTO users (full_name, email, password_hash, role, company_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (full_name, email.lower().strip(), password_hash, role, company_name, datetime.now(timezone.utc).isoformat()),
        )
        return cursor.lastrowid


def get_user_by_email(email: str) -> sqlite3.Row | None:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower().strip(),))
        return cursor.fetchone()


def get_user_by_id(user_id: int) -> sqlite3.Row | None:
    with get_conn() as conn:
        cursor = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        return cursor.fetchone()


def email_exists(email: str) -> bool:
    return get_user_by_email(email) is not None


def count_users() -> int:
    with get_conn() as conn:
        cursor = conn.execute("SELECT COUNT(*) as c FROM users")
        return cursor.fetchone()["c"]


def set_user_active(user_id: int, is_active: bool) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active = ? WHERE id = ?", (int(is_active), user_id))
