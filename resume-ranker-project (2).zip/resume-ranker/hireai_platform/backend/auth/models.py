"""Request/response schemas + validation for the auth API."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

from hireai_platform.backend.auth.security import validate_password_strength

Role = Literal["job_seeker", "recruiter"]  # admin accounts are seeded, not self-registered


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str
    confirm_password: str
    role: Role
    company_name: str | None = Field(default=None, max_length=150)

    @field_validator("full_name")
    @classmethod
    def name_not_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Full name cannot be blank.")
        return v

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        problems = validate_password_strength(v)
        if problems:
            raise ValueError(" ".join(problems))
        return v

    @field_validator("confirm_password")
    @classmethod
    def passwords_match(cls, v: str, info) -> str:
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("Passwords do not match.")
        return v

    @field_validator("company_name")
    @classmethod
    def strip_company_name(cls, v: str | None) -> str | None:
        return v.strip() if v else v

    @model_validator(mode="after")
    def recruiter_requires_company(self) -> "RegisterRequest":
        # NOTE: this MUST be a model_validator (runs after all fields are
        # resolved, including unset ones falling back to their default),
        # not a field_validator on company_name -- field_validator on an
        # unset field with a default does not run at all in Pydantic v2,
        # which silently let recruiters register with no company the first
        # time this was written. Caught by a functional test, not by
        # inspection -- worth remembering.
        if self.role == "recruiter" and not (self.company_name and self.company_name.strip()):
            raise ValueError("Company name is required for recruiter accounts.")
        return self


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    full_name: str
    email: str
    role: str
    company_name: str | None = None
    is_verified: bool


class MessageResponse(BaseModel):
    message: str
