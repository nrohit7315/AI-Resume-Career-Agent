"""Security primitives for the auth system.

Design choices (documented so they're auditable, not just asserted):

- Password hashing: PBKDF2-HMAC-SHA256 via Python's built-in `hashlib`
  (no external crypto dependency to install/trust) with a per-user random
  16-byte salt (`secrets.token_hex`) and 260,000 iterations (OWASP's 2023
  minimum recommendation for PBKDF2-SHA256 is 210,000+; we round up).
  Equivalent security posture to bcrypt/argon2 for this scale, with zero
  extra dependencies.
- Session tokens: signed, expiring JWTs (PyJWT) stored in an HttpOnly,
  SameSite=Strict, Secure cookie -- never exposed to client-side JS, which
  closes off the most common XSS-token-theft path. The server SECRET_KEY
  is read from environment (.env, gitignored), never hardcoded.
- Constant-time comparison (`hmac.compare_digest`) is used when checking
  password hashes to prevent timing side-channel attacks.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import time
from datetime import datetime, timedelta, timezone

import jwt

PBKDF2_ITERATIONS = 260_000
SALT_BYTES = 16

SECRET_KEY = os.environ.get("PLATFORM_SECRET_KEY")
if not SECRET_KEY:
    # Dev-friendly fallback so the app never hard-crashes on first run, but
    # loudly warns -- production deployments MUST set PLATFORM_SECRET_KEY.
    SECRET_KEY = secrets.token_hex(32)
    print(
        "[security] WARNING: PLATFORM_SECRET_KEY not set in environment. "
        "Using a random ephemeral key for this process only -- all existing "
        "sessions will be invalidated on restart. Set PLATFORM_SECRET_KEY "
        "in a .env file for production use."
    )

JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_TTL_MINUTES = 60 * 12  # 12 hours


def hash_password(password: str) -> str:
    """Returns a single string encoding algorithm + salt + hash, so the
    salt never needs a separate DB column and old hashes stay verifiable
    even if we bump iteration count later (format is self-describing).
    """
    salt = secrets.token_hex(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt}${digest.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, iterations_str, salt, hex_digest = stored_hash.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        iterations = int(iterations_str)
    except (ValueError, AttributeError):
        return False

    computed = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations)
    return hmac.compare_digest(computed.hex(), hex_digest)


def create_access_token(user_id: int, email: str, role: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "email": email,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=ACCESS_TOKEN_TTL_MINUTES),
        "jti": secrets.token_hex(8),  # unique token id, useful for future revocation lists
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError:
        return None


def validate_password_strength(password: str) -> list[str]:
    """Returns a list of human-readable problems; empty list = OK."""
    problems = []
    if len(password) < 8:
        problems.append("Password must be at least 8 characters long.")
    if not any(c.isupper() for c in password):
        problems.append("Password must include at least one uppercase letter.")
    if not any(c.islower() for c in password):
        problems.append("Password must include at least one lowercase letter.")
    if not any(c.isdigit() for c in password):
        problems.append("Password must include at least one number.")
    if not any(not c.isalnum() for c in password):
        problems.append("Password must include at least one special character.")
    return problems


# ---------------------------------------------------------------------------
# Minimal in-memory login-attempt rate limiter (per-process).
# For a multi-instance production deployment this should move to Redis or
# the database, but for a single-instance app this closes the most obvious
# brute-force door at zero extra infrastructure cost.
# ---------------------------------------------------------------------------
_failed_attempts: dict[str, list[float]] = {}
MAX_ATTEMPTS = 5
LOCKOUT_WINDOW_SECONDS = 15 * 60


def register_failed_attempt(email: str) -> None:
    now = time.time()
    attempts = _failed_attempts.setdefault(email.lower(), [])
    attempts.append(now)
    _failed_attempts[email.lower()] = [t for t in attempts if now - t < LOCKOUT_WINDOW_SECONDS]


def clear_failed_attempts(email: str) -> None:
    _failed_attempts.pop(email.lower(), None)


def is_locked_out(email: str) -> bool:
    now = time.time()
    attempts = _failed_attempts.get(email.lower(), [])
    recent = [t for t in attempts if now - t < LOCKOUT_WINDOW_SECONDS]
    return len(recent) >= MAX_ATTEMPTS
