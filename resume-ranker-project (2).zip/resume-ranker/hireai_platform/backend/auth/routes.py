"""Auth API routes + reusable auth dependencies for protecting other routers."""
from __future__ import annotations

from fastapi import APIRouter, Cookie, Depends, HTTPException, Response, status

from hireai_platform.backend.auth import db
from hireai_platform.backend.auth.models import LoginRequest, MessageResponse, RegisterRequest, UserOut
from hireai_platform.backend.auth.security import (
    clear_failed_attempts,
    create_access_token,
    decode_access_token,
    hash_password,
    is_locked_out,
    register_failed_attempt,
    verify_password,
)
import os

router = APIRouter(prefix="/auth", tags=["auth"])

COOKIE_NAME = "hireai_session"

# The `Secure` cookie flag tells the browser to only ever send this cookie
# over HTTPS -- correct and important in production, but it silently makes
# the cookie invisible during local http:// development/testing if left on
# unconditionally. Toggle it based on environment instead of hardcoding.
COOKIE_SECURE = os.environ.get("PLATFORM_ENV", "development").lower() == "production"


def _row_to_user_out(row) -> UserOut:
    return UserOut(
        id=row["id"],
        full_name=row["full_name"],
        email=row["email"],
        role=row["role"],
        company_name=row["company_name"],
        is_verified=bool(row["is_verified"]),
    )


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest):
    if db.email_exists(payload.email):
        raise HTTPException(status_code=409, detail="An account with this email already exists.")

    pw_hash = hash_password(payload.password)
    user_id = db.create_user(
        full_name=payload.full_name,
        email=str(payload.email),
        password_hash=pw_hash,
        role=payload.role,
        company_name=payload.company_name,
    )
    row = db.get_user_by_id(user_id)
    return _row_to_user_out(row)


@router.post("/login", response_model=UserOut)
def login(payload: LoginRequest, response: Response):
    email = str(payload.email)

    if is_locked_out(email):
        raise HTTPException(
            status_code=429,
            detail="Too many failed login attempts. Please try again in 15 minutes.",
        )

    row = db.get_user_by_email(email)
    if row is None or not verify_password(payload.password, row["password_hash"]):
        register_failed_attempt(email)
        raise HTTPException(status_code=401, detail="Incorrect email or password.")

    if not row["is_active"]:
        raise HTTPException(status_code=403, detail="This account has been deactivated.")

    clear_failed_attempts(email)
    token = create_access_token(user_id=row["id"], email=row["email"], role=row["role"])

    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        httponly=True,       # not readable by client-side JS -> blocks XSS token theft
        samesite="strict",   # blocks the cookie being sent on cross-site requests -> CSRF mitigation
        secure=COOKIE_SECURE,  # True in production (HTTPS only); False for local http:// dev/testing
        max_age=60 * 60 * 12,
        path="/",
    )
    return _row_to_user_out(row)


@router.post("/logout", response_model=MessageResponse)
def logout(response: Response):
    response.delete_cookie(COOKIE_NAME, path="/")
    return MessageResponse(message="Logged out successfully.")


def get_current_user(hireai_session: str | None = Cookie(default=None)) -> UserOut:
    if hireai_session is None:
        raise HTTPException(status_code=401, detail="Not authenticated.")

    payload = decode_access_token(hireai_session)
    if payload is None:
        raise HTTPException(status_code=401, detail="Session expired or invalid. Please log in again.")

    row = db.get_user_by_id(int(payload["sub"]))
    if row is None or not row["is_active"]:
        raise HTTPException(status_code=401, detail="Account not found or deactivated.")

    return _row_to_user_out(row)


def require_role(*allowed_roles: str):
    """Usage: Depends(require_role("recruiter", "admin"))"""

    def _dependency(user: UserOut = Depends(get_current_user)) -> UserOut:
        if user.role not in allowed_roles:
            raise HTTPException(status_code=403, detail="You don't have permission to access this resource.")
        return user

    return _dependency


@router.get("/me", response_model=UserOut)
def me(user: UserOut = Depends(get_current_user)):
    return user
